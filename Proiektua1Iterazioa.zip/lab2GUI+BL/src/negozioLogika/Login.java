package negozioLogika;

public interface Login {
	public boolean loginEgin (String login, String password, String type);

}
