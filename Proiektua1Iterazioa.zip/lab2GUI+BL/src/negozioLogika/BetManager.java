package negozioLogika;

import java.util.ArrayList;

import domain.SistemaGertaera;

public class BetManager {

	private ArrayList<SistemaGertaera> gertaerak;

	public ArrayList<SistemaGertaera> getGertaerak() {
		return gertaerak;
	}

	public void setGertaerak(ArrayList<SistemaGertaera> gertaerak) {
		this.gertaerak = gertaerak;
	}

	public BetManager(ArrayList<SistemaGertaera> gertaerak) {
		super();
		this.gertaerak = gertaerak;
	}
	public BetManager() {
		this.gertaerak = new ArrayList<SistemaGertaera>();
	}
	
	public void gehituGertaera(SistemaGertaera g) {
		gertaerak.add(g);
	}
}
