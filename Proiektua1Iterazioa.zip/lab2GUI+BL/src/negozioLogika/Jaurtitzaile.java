package negozioLogika;

import gui.*;

public class Jaurtitzaile {

	public static void main(String[] args) {
		Aurkezpena a=new Aurkezpena();
		BezeroOrria bezeroO = new BezeroOrria();
		AdminOrria adminO = new AdminOrria();
		BetManager bm = new BetManager();
		Login l=new Login2();
		a.setLoginLogika(l);
		a.setVisible(true);
		adminO.setNegozioLogika(bm);
	}

}
