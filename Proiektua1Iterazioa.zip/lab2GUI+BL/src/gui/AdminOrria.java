package gui;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;

import negozioLogika.BetManager;
import negozioLogika.Login;
import negozioLogika.Login2;
import domain.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.awt.Font;

public class AdminOrria extends JFrame{
	private JTextField txtGertaera;
	private JTextField txtGaldera;
	private JTextField txtApustuMin;
	private JTextField txtPronostikoa;
	private JTextField txtIrabazia;
	
	private BetManager negozioLogika;
	private JTextArea textArea;
	
	public void setNegozioLogika(BetManager nl) {
		negozioLogika=nl;
	}
	
	
	public AdminOrria() {
		getContentPane().setLayout(null);
		this.setSize(800, 475);
		this.setLocation(400,200);
		JLabel lblgertaera = new JLabel("Gertaera:");
		lblgertaera.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblgertaera.setBounds(76, 61, 69, 21);
		getContentPane().add(lblgertaera);
		
		JLabel lblGaldera = new JLabel("Galdera:");
		lblGaldera.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGaldera.setBounds(76, 117, 69, 21);
		getContentPane().add(lblGaldera);
		
		JLabel lblApustuMinimoa = new JLabel("Apustu minimoa:");
		lblApustuMinimoa.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblApustuMinimoa.setBounds(76, 164, 145, 21);
		getContentPane().add(lblApustuMinimoa);
		
		JLabel lblPronostikoa = new JLabel("Pronostikoa:");
		lblPronostikoa.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPronostikoa.setBounds(77, 218, 98, 21);
		getContentPane().add(lblPronostikoa);
		
		JLabel lblIrabazia = new JLabel("Irabazia:");
		lblIrabazia.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblIrabazia.setBounds(76, 270, 69, 21);
		getContentPane().add(lblIrabazia);
		
		txtGertaera = new JTextField();
		txtGertaera.setBounds(217, 48, 362, 34);
		getContentPane().add(txtGertaera);
		txtGertaera.setColumns(10);
		
		txtGaldera = new JTextField();
		txtGaldera.setColumns(10);
		txtGaldera.setBounds(217, 104, 362, 34);
		getContentPane().add(txtGaldera);
		
		txtApustuMin = new JTextField();
		txtApustuMin.setColumns(10);
		txtApustuMin.setBounds(217, 151, 362, 34);
		getContentPane().add(txtApustuMin);
		
		txtPronostikoa = new JTextField();
		txtPronostikoa.setColumns(10);
		txtPronostikoa.setBounds(217, 214, 362, 34);
		getContentPane().add(txtPronostikoa);
		
		txtIrabazia = new JTextField();
		txtIrabazia.setColumns(10);
		txtIrabazia.setBounds(217, 266, 362, 34);
		getContentPane().add(txtIrabazia);
		
		JButton btnGehituGertaera = new JButton("Gehitu gertaera");
		btnGehituGertaera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String gertaera = txtGertaera.getText();
				String galdera = txtGaldera.getText();
				float apustuMin = Float.parseFloat(txtApustuMin.getText());
				String pronostikoa = txtPronostikoa.getText();
				float irabazia = Float.parseFloat(txtIrabazia.getText());
				Galdera galderaBerria = new Galdera(galdera,new Gertaera(gertaera,""),apustuMin);
				Pronostikoa pronostikoBerria = new Pronostikoa(pronostikoa,irabazia);
				negozioLogika.gehituGertaera(new SistemaGertaera(galderaBerria,pronostikoBerria));
				
			}
		});
		btnGehituGertaera.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnGehituGertaera.setBounds(291, 353, 145, 34);
		getContentPane().add(btnGehituGertaera);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Courier New", Font.PLAIN, 15));
		textArea.setBounds(516, 366, 127, 42);
		getContentPane().add(textArea);
	}
}
