package gui;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import domain.Galdera;
import domain.Gertaera;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;

import negozioLogika.*;
import domain.*;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.awt.Font;

public class BezeroOrria extends JFrame{
	private JTextField txtApustua;
	private BetManager negozioLogika;
	private SistemaGertaera aukeratutakoGertaera;
	private Apustua egindakoApustua;
	
	public void setNegozioLogika(BetManager bm) {
		negozioLogika=bm;
	}
	public BezeroOrria() {
		getContentPane().setLayout(null);
		
		this.setSize(800, 475);
		this.setLocation(400,200);
		
		negozioLogika = new BetManager();
		negozioLogika.kargatuGertaerak();
		JComboBox cmbApustuak = new JComboBox();
		cmbApustuak.setBounds(253, 54, 310, 37);
		getContentPane().add(cmbApustuak);
		for (SistemaGertaera sg:negozioLogika.getGertaerak()) {
			cmbApustuak.addItem(sg.getGaldera().getGertaera().getDeskripzioa());
		}
		
		JLabel lblNewLabel = new JLabel("Aukeratu gertaera bat:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(74, 59, 129, 25);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Gertaera:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(87, 136, 95, 25);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Galdera:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(87, 181, 95, 25);
		getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Pronostikoa:");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_2.setBounds(87, 261, 95, 25);
		getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Apustu kantitatea:");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_3.setBounds(87, 303, 116, 25);
		getContentPane().add(lblNewLabel_1_3);
		
		JTextArea txtGertaera = new JTextArea();
		txtGertaera.setBounds(253, 136, 310, 30);
		getContentPane().add(txtGertaera);
		
		JTextArea txtGaldera = new JTextArea();
		txtGaldera.setBounds(253, 176, 310, 30);
		getContentPane().add(txtGaldera);
		
		JTextArea txtApustuMin = new JTextArea();
		txtApustuMin.setBounds(253, 216, 310, 30);
		getContentPane().add(txtApustuMin);
		
		txtApustua = new JTextField();
		txtApustua.setBounds(253, 302, 310, 30);
		getContentPane().add(txtApustua);
		txtApustua.setColumns(10);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Apustu minimoa:");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_2_1.setBounds(87, 216, 95, 25);
		getContentPane().add(lblNewLabel_1_2_1);
		
		JTextArea txtPronostikoa = new JTextArea();
		txtPronostikoa.setBounds(253, 256, 310, 30);
		getContentPane().add(txtPronostikoa);
		
		JTextArea txtIrabazia = new JTextArea();
		txtIrabazia.setBounds(324, 330, 167, 30);
		getContentPane().add(txtIrabazia);
		
		JButton btnApustuaEgin = new JButton("Apustua egin");
		btnApustuaEgin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Double.parseDouble(txtApustua.getText()) >= Double.parseDouble(txtApustuMin.getText())/*&&dirua dauka erabiltzaileak*/) {					
					egindakoApustua = new Apustua(aukeratutakoGertaera.getGaldera(),aukeratutakoGertaera.getPronostikoa(),Double.parseDouble(txtApustua.getText()));
					//Erabiltzailearen kontuan gorde apustu berria
				}			
			}
		});
		btnApustuaEgin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnApustuaEgin.setBounds(341, 391, 135, 37);
		getContentPane().add(btnApustuaEgin);
		
		JButton btnAukeratu = new JButton("Aukeratu");
		btnAukeratu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnApustuaEgin.setEnabled(true);
				aukeratutakoGertaera=negozioLogika.bilatuGertaera((String)cmbApustuak.getSelectedItem());
				txtGertaera.setText(aukeratutakoGertaera.getGaldera().getGertaera().getDeskripzioa());
				txtGaldera.setText(aukeratutakoGertaera.getGaldera().getDeskripzioa());
				txtApustuMin.setText(Double.toString(aukeratutakoGertaera.getGaldera().getApustuMin()));
				txtPronostikoa.setText(aukeratutakoGertaera.getPronostikoa().getEmaitza());
			}
		});
		btnAukeratu.setBounds(356, 101, 85, 21);
		getContentPane().add(btnAukeratu);
	}
}
