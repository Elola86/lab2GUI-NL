package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;

import negozioLogika.BetManager;
import negozioLogika.Login;
import negozioLogika.Login2;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;

public class Aurkezpena extends JFrame {

	private JPanel contentPane;
	private JTextField txtLogin;
	private  ButtonGroup buttonGroup = new ButtonGroup();
	private Login loginLogika;
	//private BetManager negozioLogika;
	private JPasswordField pwdPassword;
	private JButton btnSistemanSartu;
	private JTextArea textArea;
	private DefaultListModel erabiltzaileak = new DefaultListModel();
	private JList erabiltzaileList;
	private BezeroOrria orriNagusia;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aurkezpena frame = new Aurkezpena();
					Login2 nl=new Login2();
					frame.setLoginLogika(nl);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Aurkezpena() {
		setTitle("Erabilpen kasua: Login egin");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtLogin = new JTextField();
		txtLogin.setText("login");
		txtLogin.setBounds(233, 23, 134, 28);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);
		
		JLabel lblErabiltzaileIzenaSartu = new JLabel("Erabiltzaile izena sartu");
		lblErabiltzaileIzenaSartu.setBounds(50, 29, 165, 16);
		contentPane.add(lblErabiltzaileIzenaSartu);
		
		JLabel lblPasahitzaSartu = new JLabel("Pasahitza sartu");
		lblPasahitzaSartu.setBounds(50, 72, 145, 16);
		contentPane.add(lblPasahitzaSartu);
		
		JLabel lblErabiltzaileMotaAukeratu = new JLabel("Erabiltzaile mota aukeratu");
		lblErabiltzaileMotaAukeratu.setBounds(30, 118, 165, 16);
		contentPane.add(lblErabiltzaileMotaAukeratu);
		
		btnSistemanSartu = new JButton("Sisteman sartu");
		btnSistemanSartu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String izena=txtLogin.getText();
				String pass=new String(pwdPassword.getPassword());
				String mota=erabiltzaileList.getSelectedValue().toString();			
				
				boolean b=loginLogika.loginEgin(izena, pass, mota);
				if (b&&mota.equals("Bezeroa")) {
					textArea.setText("Aurrera");
					BezeroOrria orria = new BezeroOrria();
					BetManager bm = new BetManager();
					orria.setNegozioLogika(bm);
					orria.setVisible(true);
					setVisible(false);
				} else if(b&&mota.equals("Administratzailea")) {
					textArea.setText("Aurrera");
					AdminOrria orria = new AdminOrria();
					BetManager bm = new BetManager();
					orria.setNegozioLogika(bm);
					orria.setVisible(true);
					setVisible(false);
				}
				else textArea.setText("Errorea");
				 
			}
		});
		btnSistemanSartu.setBounds(178, 158, 117, 29);
		contentPane.add(btnSistemanSartu);
		
		textArea = new JTextArea();
		textArea.setBounds(94, 199, 290, 55);
		contentPane.add(textArea);
		
		pwdPassword = new JPasswordField();
		pwdPassword.setText("password");
		pwdPassword.setBounds(233, 66, 134, 28);
		contentPane.add(pwdPassword);
		
		erabiltzaileList = new JList();
		erabiltzaileList.setBounds(233, 119, 134, 37);
		contentPane.add(erabiltzaileList);
		erabiltzaileList.setModel(erabiltzaileak);
		erabiltzaileak.addElement("Bezeroa");
		erabiltzaileak.addElement("Administratzailea");

	}
	public void setLoginLogika (Login l){
		loginLogika=l;
	}
	public void setOrriNagusia (BezeroOrria orria) {
		orriNagusia=orria;
	}

}

