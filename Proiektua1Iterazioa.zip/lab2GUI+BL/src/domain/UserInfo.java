package domain;

import java.util.LinkedList;

public class UserInfo {

	private String izena;
	private String pasahitza;
	private double dirua;
	private LinkedList<Apustua> apustuak;
	
	public UserInfo(String izena, String pasahitza, double dirua, LinkedList<Apustua> apustuak) {
		this.izena = izena;
		this.pasahitza = pasahitza;
		this.dirua = dirua;
		this.apustuak = apustuak;
	}
	
	
	
}
