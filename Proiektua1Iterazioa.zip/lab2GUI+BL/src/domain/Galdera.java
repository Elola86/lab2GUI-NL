package domain;

public class Galdera {

	private String deskripzioa;
	private Gertaera gertaera;
	private double apustuMin;
	
	public Galdera(String deskripzioa, Gertaera gertaera, double apustuMin) {

		this.deskripzioa = deskripzioa;
		this.gertaera = gertaera;
		this.apustuMin = apustuMin;
	}
	
}