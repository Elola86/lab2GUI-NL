package domain;

public class Galdera {

	private String deskripzioa;
	private Gertaera gertaera;
	private double apustuMin;
	
	public String getDeskripzioa() {
		return deskripzioa;
	}

	public void setDeskripzioa(String deskripzioa) {
		this.deskripzioa = deskripzioa;
	}

	public Gertaera getGertaera() {
		return gertaera;
	}

	public void setGertaera(Gertaera gertaera) {
		this.gertaera = gertaera;
	}

	public double getApustuMin() {
		return apustuMin;
	}

	public void setApustuMin(double apustuMin) {
		this.apustuMin = apustuMin;
	}
	
	public Galdera(String deskripzioa, Gertaera gertaera, double apustuMin) {

		this.deskripzioa = deskripzioa;
		this.gertaera = gertaera;
		this.apustuMin = apustuMin;
	}
	
	public Galdera() {

		this.deskripzioa = null;
		this.gertaera = new Gertaera();
		this.apustuMin = 0;
	}
	
}