package domain;

public class SistemaGertaera {

	private Galdera galdera;
	private Pronostikoa pronostikoa;
	public Galdera getGaldera() {
		return galdera;
	}
	public void setGaldera(Galdera galdera) {
		this.galdera = galdera;
	}
	public Pronostikoa getPronostikoa() {
		return pronostikoa;
	}
	public void setPronostikoa(Pronostikoa pronostikoa) {
		this.pronostikoa = pronostikoa;
	}
	
	public SistemaGertaera(Galdera galdera, Pronostikoa pronostikoa) {
		this.galdera = galdera;
		this.pronostikoa = pronostikoa;
	}
	public SistemaGertaera() {
		this.galdera = new Galdera();
		this.pronostikoa = new Pronostikoa();
	}
}
