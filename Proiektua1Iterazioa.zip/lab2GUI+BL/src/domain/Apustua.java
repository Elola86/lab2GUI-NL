package domain;

public class Apustua {

	private Galdera galdera;
	private Pronostikoa pronostikoa;
	private float apustutakoDirua;
	
	public Apustua(Galdera galdera, Pronostikoa pronostikoa, float apustutakoDirua) {
		this.galdera = galdera;
		this.pronostikoa = pronostikoa;
		this.apustutakoDirua = apustutakoDirua;
	}
	
	
}
