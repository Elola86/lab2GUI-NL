package domain;

public class Apustua {

	private Galdera galdera;
	private Pronostikoa pronostikoa;
	private float apustutakoDirua;
	public Galdera getGaldera() {
		return galdera;
	}

	public void setGaldera(Galdera galdera) {
		this.galdera = galdera;
	}

	public Pronostikoa getPronostikoa() {
		return pronostikoa;
	}

	public void setPronostikoa(Pronostikoa pronostikoa) {
		this.pronostikoa = pronostikoa;
	}

	public float getApustutakoDirua() {
		return apustutakoDirua;
	}

	public void setApustutakoDirua(float apustutakoDirua) {
		this.apustutakoDirua = apustutakoDirua;
	}	
	
	public Apustua(Galdera galdera, Pronostikoa pronostikoa, float apustutakoDirua) {
		this.galdera = galdera;
		this.pronostikoa = pronostikoa;
		this.apustutakoDirua = apustutakoDirua;
	}
	
	
}
