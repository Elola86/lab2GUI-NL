package domain;

import java.util.Calendar;

public class Gertaera {

	private String deskripzioa;
	private Calendar data;
	public String getDeskripzioa() {
		return deskripzioa;
	}

	public void setDeskripzioa(String deskripzioa) {
		this.deskripzioa = deskripzioa;
	}
	
	public Calendar getData() {
		return data;
	}

	public void setData(Calendar data) {
		this.data = data;
	}

	public Gertaera(String deskripzioa) {
		this.deskripzioa = deskripzioa;
		this.data = data.getInstance();
	}
	public Gertaera() {
		this.deskripzioa = null;
		this.data = data.getInstance();
	}
}
