package domain;

public class Gertaera {

	private String deskripzioa;
	private String data;
	public String getDeskripzioa() {
		return deskripzioa;
	}

	public void setDeskripzioa(String deskripzioa) {
		this.deskripzioa = deskripzioa;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Gertaera(String deskripzioa, String data) {
		this.deskripzioa = deskripzioa;
		this.data = data;
	}
	public Gertaera() {
		this.deskripzioa = null;
		this.data = null;
	}
}
