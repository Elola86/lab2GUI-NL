package domain;

public class Gertaera {

	private String deskripzioa;
	private String data;

	public Gertaera(String deskripzioa, String data) {

		this.deskripzioa = deskripzioa;
		this.data = data;
	}
	
}
