package domain;

public class Pronostikoa {

	private String emaitza;
	private double irabazia;
	public Pronostikoa(String emaitza, double irabazia) {
		super();
		this.emaitza = emaitza;
		this.irabazia = irabazia;
	}
	
	
}
