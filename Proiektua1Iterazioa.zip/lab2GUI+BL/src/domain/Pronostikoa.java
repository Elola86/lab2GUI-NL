package domain;

public class Pronostikoa {

	private String emaitza;
	private double irabazia;
	public Pronostikoa(String emaitza, double irabazia) {
		this.emaitza = emaitza;
		this.irabazia = irabazia;
	}
	public Pronostikoa() {
		this.emaitza = null;
		this.irabazia = 0;
	}
	public String getEmaitza() {
		return emaitza;
	}
	public void setEmaitza(String emaitza) {
		this.emaitza = emaitza;
	}
	public double getIrabazia() {
		return irabazia;
	}
	public void setIrabazia(double irabazia) {
		this.irabazia = irabazia;
	}
	
	
}
